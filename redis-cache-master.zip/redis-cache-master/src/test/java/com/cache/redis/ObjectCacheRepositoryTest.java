/*
 *  PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA
 *
 *   Copyright © 2021. Pearson Education, Inc.
 *   All Rights Reserved.
 *
 *  NOTICE:  All information contained herein is, and remains
 *  the property of Pearson Education, Inc.  The intellectual and technical concepts contained
 *  herein are proprietary to Pearson Education, Inc. and may be covered by U.S. and Foreign Patents,
 *  patent applications, and are protected by trade secret or copyright law.
 *  Dissemination of this information, reproduction of this material, and copying or distribution of this software
 *  is strictly forbidden unless prior written permission is obtained from Pearson Education, Inc..
 */
package com.cache.redis;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.data.redis.connection.RedisClusterConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import com.cache.redis.repository.RedisObjectCacheRepository;
import com.cache.redis.utils.CacheException;


public class ObjectCacheRepositoryTest {
	
	private RedisObjectCacheRepository cacheObj;
	
	@SuppressWarnings("unchecked")
	private HashOperations<String, Object, Object> hashOperations = Mockito.mock(HashOperations.class);
	
	@SuppressWarnings("unchecked")
	private ValueOperations<String, Object> valueOperations = Mockito.mock(ValueOperations.class);
	
	@SuppressWarnings("unchecked")
	private RedisTemplate<String, Object> redisTemplate = Mockito.mock(RedisTemplate.class);
	
	@Before
	public void before() {		
		
		Mockito.when(redisTemplate.opsForHash()).thenReturn(hashOperations);
		Mockito.when(redisTemplate.opsForValue()).thenReturn(valueOperations);
		
		cacheObj = new RedisObjectCacheRepository(redisTemplate);
	}
	
	@Test
	public void storeInCacheWithHash() {
		
		String key = "key";
		String hashKey = "hashKey";
		String value = "123";
		long expiryTimeInSecond = 1;
		Mockito.doNothing().when(hashOperations).put(key, hashKey, value);
		Mockito.when(redisTemplate.expire(key, expiryTimeInSecond, TimeUnit.SECONDS)).thenReturn(true);
		cacheObj.put(key, hashKey, value, expiryTimeInSecond);
		assertTrue("Failed to store value in cache", true);		
		
	}
	
	@Test
	public void storeInCacheWithValue() {
		
		String key = "key";		
		String value = "123";
		long expiryTimeInSecond = 1;
		Mockito.doNothing().when(valueOperations).set(key, value);
		Mockito.when(redisTemplate.expire(key, expiryTimeInSecond, TimeUnit.SECONDS)).thenReturn(true);
		cacheObj.put(key, value, expiryTimeInSecond);
		assertTrue("Failed to store value in cache", true);		
		
	}
	
	@Test
	public void storeMapInCacheWithHash() {
		
		String key = "key";		
		
		long expiryTimeInSecond = 1;
		final Map<String, Object> value = new HashMap<String, Object>();
		Mockito.doNothing().when(hashOperations).putAll(key, value);
		Mockito.when(redisTemplate.expire(key, expiryTimeInSecond, TimeUnit.SECONDS)).thenReturn(true);
		cacheObj.putAll(key, value, expiryTimeInSecond);
		assertTrue("Failed to store value in cache", true);		
		
	}
	
	@Test(expected = CacheException.class)
	public void storeInCacheWithHashForException() {
		
		String key = "key";
		String hashKey = "hashKey";
		String value = "123";
		long expiryTimeInSecond = 1;
		Mockito.doThrow(new CacheException("Error in data store")).when(hashOperations).put(key, hashKey, value);
		cacheObj.put(key, hashKey, value, expiryTimeInSecond);		
		
	}
	
	@Test(expected = CacheException.class)
	public void storeInCacheWithValueForException() {
		
		String key = "key";		
		String value = "123";
		long expiryTimeInSecond = 1;
		Mockito.doThrow(new CacheException("Error in data store")).when(valueOperations).set(key, value);
		cacheObj.put(key, value, expiryTimeInSecond);		
		
	}
	
	@Test(expected = CacheException.class)
	public void storeMapInCacheWithHashForException() {
		
		String key = "key";		
		
		final Map<String, Object> value = new HashMap<String, Object>();
		long expiryTimeInSecond = 1;
		Mockito.doThrow(new CacheException("Error in data store")).when(hashOperations).putAll(key, value);
		cacheObj.putAll(key, value, expiryTimeInSecond);		
		
	}
	
	
	@Test
	public void getInCache() {
		
		String key = "key";
		String hashKey = "hashKey";
		String value = "123";
		Mockito.when(hashOperations.get(key, hashKey)).thenReturn(value);
		String returnValue = cacheObj.get(key, hashKey).toString();		
		assertEquals("Invalid value returned", "123", returnValue);
		
	}
	
	@Test
	public void getValueInCache() {
		
		String key = "key";		
		String value = "123";
		Mockito.when(valueOperations.get(key)).thenReturn(value);
		String returnValue = cacheObj.get(key).toString();		
		assertEquals("Invalid value returned", "123", returnValue);
		
	}
	
	@Test(expected = CacheException.class)
	public void getInCacheForException() {
		
		String key = "key";
		String hashKey = "hashKey";
		
		Mockito.doThrow(new CacheException("Error in data get")).when(hashOperations).get(key, hashKey);
		cacheObj.get(key, hashKey);		
		
	}
	
	@Test(expected = CacheException.class)
	public void getValueCacheForException() {
		
		String key = "key";
				
		Mockito.doThrow(new CacheException("Error in data get")).when(valueOperations).get(key);
		cacheObj.get(key);		
		
	}
	
	@Test
	public void getAllInCache() {
		
		String key = "key";
		String hashKey = "hashKey";
		String value = "123";
		Map<Object, Object> allValue = new HashMap<>();
		allValue.put("hashKey", "123");
		Mockito.when(hashOperations.entries(key)).thenReturn(allValue);
		Map<String, Object> returnValue = cacheObj.getAll(key);
		assertNotNull("Null map returned", returnValue);
		assertEquals("Invalid value returned", "123", returnValue.get(hashKey));
		
	}
	
	@Test(expected = CacheException.class)
	public void getAllCacheForException() {
		
		String key = "key";		
		Mockito.when(hashOperations.entries(key)).thenThrow(new CacheException("Error in data get"));
		cacheObj.getAll(key);		
		
	}
	
	
	
	@Test
	public void deleteCache() {
		
		String key = "key";
		String hashKey = "hashKey";		
		Mockito.when(hashOperations.delete(key, hashKey)).thenReturn(new Long(1));
		Long status = cacheObj.delete(key, hashKey);
		assertEquals("Invalid value returned", new Long(1), status);		
		
	}
	
	@Test
	public void deleteAll() {
		
		RedisConnectionFactory conFac = Mockito.mock(RedisConnectionFactory.class);
		RedisClusterConnection clustercon = Mockito.mock(RedisClusterConnection.class);
		Mockito.when(redisTemplate.getConnectionFactory()).thenReturn(conFac);
		Mockito.when(conFac.getClusterConnection()).thenReturn(clustercon);
		redisTemplate.getConnectionFactory().getClusterConnection().flushAll();
					
		Mockito.doNothing().when(clustercon).flushAll();
		cacheObj.deleteAll();
		assertTrue("Successfully deleted all cache", true);		
		
	}
	
	@Test(expected = CacheException.class)
	public void deleteAllWhenException() {
		
		RedisConnectionFactory conFac = Mockito.mock(RedisConnectionFactory.class);
		RedisClusterConnection clustercon = Mockito.mock(RedisClusterConnection.class);
		Mockito.when(redisTemplate.getConnectionFactory()).thenReturn(conFac);
		Mockito.when(conFac.getClusterConnection()).thenReturn(clustercon);
		redisTemplate.getConnectionFactory().getClusterConnection().flushAll();
					
		Mockito.doThrow(new CacheException("Error flush the cache")).when(clustercon).flushAll();
		cacheObj.deleteAll();				
		
	}
	
	@Test(expected = CacheException.class)
	public void deleteCacheForException() {
		
		String key = "key";
		String hashKey = "hashKey";		
		Mockito.when(hashOperations.delete(key, hashKey)).thenThrow(new CacheException("Error in data delete"));
		cacheObj.delete(key, hashKey);		
		
	}
}
