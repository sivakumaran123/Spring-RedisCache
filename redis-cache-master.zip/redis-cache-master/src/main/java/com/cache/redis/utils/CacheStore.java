package com.cache.redis.utils;

public enum CacheStore {

	REDIS;
}

