package com.cache.redis.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.cache.redis.repository.RedisObjectCacheRepository;

@RefreshScope
@Configuration
public class RedisConfig {

	private static Logger LOGGER = LogManager.getLogger(RedisConfig.class);
			
			
	@Value("${spring.redis.clusterurl}")
	private String redisClusterNodes;

	@Bean(value = "lettuceConnectionFactory")
	@Primary
	LettuceConnectionFactory lettuceConnectionFactory() {
		
		LOGGER.info("Redis cluster url: " + redisClusterNodes);
		List<String> nodes = new ArrayList<>();
		nodes.add(redisClusterNodes);

		LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder().useSsl().and()
				.commandTimeout(Duration.ofSeconds(3)).shutdownTimeout(Duration.ZERO).build();

		RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration(nodes);
		LettuceConnectionFactory lcf = new LettuceConnectionFactory(redisClusterConfiguration, clientConfig);
		lcf.afterPropertiesSet();

		return lcf;
	}

	@Bean(value = "redisTemplate")
	public RedisTemplate<String, Object> redisTemplate() {
		
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();

		RedisSerializer<String> stringSerializer = new StringRedisSerializer();
		JdkSerializationRedisSerializer jdkSerializationRedisSerializer = new JdkSerializationRedisSerializer();

		redisTemplate.setConnectionFactory(lettuceConnectionFactory());

		redisTemplate.setKeySerializer(stringSerializer);
		redisTemplate.setHashKeySerializer(stringSerializer);

		redisTemplate.setValueSerializer(jdkSerializationRedisSerializer);
		redisTemplate.setHashValueSerializer(jdkSerializationRedisSerializer);

		redisTemplate.setEnableTransactionSupport(true);
		redisTemplate.afterPropertiesSet();

		return redisTemplate;
	}

	@Bean(value = "stringRedisTemplate")
	public StringRedisTemplate stringRedisTemplate() {

		StringRedisTemplate stringRedisTemplate = new StringRedisTemplate();
		
		stringRedisTemplate.setConnectionFactory(lettuceConnectionFactory());		

		return stringRedisTemplate;
	}

	@Bean(value = "redisObjectCacheRepository")
	public RedisObjectCacheRepository getObjectCacheRepository() {
		RedisObjectCacheRepository objectCacheRepository = new RedisObjectCacheRepository(redisTemplate());
		return objectCacheRepository;
	}
}
