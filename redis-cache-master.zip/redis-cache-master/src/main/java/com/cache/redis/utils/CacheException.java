package com.cache.redis.utils;

public class CacheException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String errorMessage;
	

	public CacheException(final String errorMessage){
		
		this.errorMessage = errorMessage;
				
	}
	
	public String getMessage() {
		
		return this.errorMessage;
	}
}
