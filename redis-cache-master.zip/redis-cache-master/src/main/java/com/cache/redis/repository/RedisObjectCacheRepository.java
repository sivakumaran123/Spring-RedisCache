package com.cache.redis.repository;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import com.cache.redis.utils.CacheException;

/**
 * 
 * Redis object repository
 *
 */
public class RedisObjectCacheRepository implements CacheRepository {

	private static Logger LOGGER = LogManager.getLogger(RedisObjectCacheRepository.class);
	
	private HashOperations<String, String, Object> hashOperations;
	
	private ValueOperations<String, Object> valueOperations;
	
	private RedisTemplate<String, Object> redisTemplate;

	public RedisObjectCacheRepository(final RedisTemplate<String, Object> redisTemplate) {
		
		this.hashOperations = redisTemplate.opsForHash();
		this.valueOperations = redisTemplate.opsForValue();
		this.redisTemplate = redisTemplate;		
		
		
	}

	@Override
	public void put(final String bucket, final String key, final Object value, final long expiryTimeInSecond) {
		
		try {
			
			LOGGER.info("Create message for bucket {0} with key {1} and value {2} with expiry {3}", bucket, key, value, expiryTimeInSecond);
			hashOperations.put(bucket, key, value);	
			
			if(expiryTimeInSecond > 0) {
				redisTemplate.expire(bucket, expiryTimeInSecond, TimeUnit.SECONDS);
			}
			
		}catch(Exception e) {
			
			LOGGER.error("Error storing data in to bucket {0}, key {1}, value {2}", bucket, key, value);
			throw new CacheException("Unable to storing data in Redis server." + e.getCause());
		}
		

	}
	
	@Override
	public void putAll(final String key, final Map<String, Object> value, final long expiryTimeInSecond) {
		
		try {
			
			LOGGER.info("Create message for bucket {0} with key {1} and value {2} with expiry {3}", key, value, expiryTimeInSecond);
			hashOperations.putAll(key, value);			
			if(expiryTimeInSecond > 0) {
				
				redisTemplate.expire(key, expiryTimeInSecond, TimeUnit.SECONDS);
			}			
			
		}catch(Exception e) {
			
			LOGGER.error("Error storing data in to bucket {0}, key {1}, value {2}", key, value);
			throw new CacheException("Unable to storing data in Redis server." + e.getCause());
		}
		

	}
	

	@Override
	public void put(final String key, final String value, final long expiryTimeInSecond) {
		
		try {
			
			LOGGER.info("Create message with key {0} and value {1} for expiry time {2}", key, value, expiryTimeInSecond);
			valueOperations.set(key, value);
			
			if(expiryTimeInSecond > 0) {
				redisTemplate.expire(key, expiryTimeInSecond, TimeUnit.SECONDS);
			}
			
		}catch(Exception e) {
			
			LOGGER.error("Error storing data in to key {0}, value {1}", key, value);
			throw new CacheException("Unable to storing data in Redis server." + e.getCause());
		}
		

	}

	@Override
	public Object get(final String bucket, final String key) {
		try {
			return hashOperations.get(bucket, key);
		} catch (Exception e) {

			LOGGER.error("Error get data for bucket {0} and key {1}", bucket, key);
			throw new CacheException("Unable get data in Redis server for key: " + key + " in " + bucket +". Error: " + e.getCause());
		}
	}
	
	@Override
	public Object get(final String key) {
		try {
			return valueOperations.get(key);
		} catch (Exception e) {

			LOGGER.error("Error get data for key {1}", key);
			throw new CacheException("Unable get data in Redis server cache for key: " + key +". Error: " + e.getCause());
		}
	}

	@Override
	public Map<String, Object> getAll(final String key) {
		try {
			return hashOperations.entries(key);
		} catch (Exception e) {

			LOGGER.error("Error get all for key {0}", key);
			throw new CacheException("Error get data in Redis server for key " + key + ". Error: " + e.getCause());
		}
	}	
	

	

	@Override
	public Long delete(final String bucket, final String key) {
		try {
			Long status = hashOperations.delete(bucket, key);
			LOGGER.info("Successfully deleted  message for bucket {0} with key {1}", bucket, key );
			return status;
		} catch (Exception e) {

			LOGGER.error("Error in delete key {0} in bucket {1}", key, bucket);
			throw new CacheException("Unable to delete data in Redis server for key " + key + " in " + bucket
					+ "." + e.getCause());
		}

	}

	@Override
	public void deleteAll() {
		
		
		try {
			
			redisTemplate.getConnectionFactory().getClusterConnection().flushAll();
			
		} catch (Exception e) {
	
			LOGGER.error("Error in delete all.");
			throw new CacheException("Unable to delete all data in cache. Error: " + e.getCause());
		}
		
	}
	
	@Override
	public void deleteKey(final String key) {		
		
		try {
			
			redisTemplate.getConnectionFactory().getClusterConnection().del(key.getBytes());
			
		} catch (Exception e) {
	
			LOGGER.error("Error in delete ket ." + key);
			throw new CacheException("Unable to delete all data in cache. Error: " + e.getCause());
		}
		
	}

}
