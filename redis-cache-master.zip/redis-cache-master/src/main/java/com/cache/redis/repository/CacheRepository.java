package com.cache.redis.repository;

import java.util.Map;

import com.cache.redis.utils.CacheException;

public interface CacheRepository {

	/**
	 * Method to store hash key value in Redis database
	 * 
	 * @param bucket Set bucket name / namespace where all relevant key value to be stored
	 * @param key Set key 
	 * @param value Set value to be stored
	 * @param expiryTimeInSecond Set expiry time in second
	 */
	void put(final String bucket, final String key, final Object value, final long expiryTimeInSecond) throws CacheException;
	
	/**
	 * Method to store hash key, value in Redis database
	 * 
	 * 
	 * @param key Set key 
	 * @param value Set value to be stored
	 * @param expiryTimeInSecond Set expire time in second
	 */
	void put(final String key, final String value, final long expiryTimeInSecond) throws CacheException;
	
	
	
	/**
	 * Method to put all key value pairs stored in of given key
	 * @param key Set bucket
	 * @param keyvalues Set key value pair
	 * @param expiryTimeInSecond Set expire time
	 * 
	 * 
	 */
	void putAll(final String key, final Map<String, Object> keyvalues, final long expiryTimeInSecond);
	

	/**
	 * Method to get a value for given key which has stored in given bucket
	 * 
	 * @param bucket Set bucket
	 * @param key Set key
	 * @return value to be return
	 */
	Object get(final String bucket, final String key);
	
	/**
	 * Method to get a value for given key 
	 * 
	 * 
	 * @param key Set key
	 * @return value to be return
	 */
	Object get(final String key);
	
	/**
	 * Method to get a value for given key 
	 * 
	 * 
	 * @param key Set key
	 * @return 
	 */
	Map<String, Object> getAll(final String key);
	

	/**
	 * Method to delete given key stored in a bucket
	 * 
	 * @param bucket Set bucket 
	 * @param key Set key
	 */
	Long delete(final String bucket, final String key);
	
	/**
	 * Delete all cache in redis
	 */
	void deleteAll();
	
	/**
	 * Delete cache for given key
	 * @param key Set key
	 */
	void deleteKey(final String key);
	
	
}