
package com.cache.redis.config;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cache.redis.utils.CacheException;
import com.cache.redis.utils.CacheStore;

@Aspect
@Component
public class CacheProcessorAspect {

	private static Logger LOGGER = LogManager.getLogger(CacheProcessorAspect.class);

	@Autowired
	@Qualifier("cacheFactory")
	private CacheFactory cacheFactory;

	@SuppressWarnings("unchecked")
	@Around("@annotation(EnableSocketCache)")
	public Object cacheData(ProceedingJoinPoint joinPoint) throws Throwable {

		Object[] parameters = joinPoint.getArgs();

		Object returnObject = null;

		if (parameters.length > 0) {
			Map<String, String> cacheParams = (Map<String, String>) parameters[parameters.length - 1];

			String key = cacheParams.get("key") != null ? cacheParams.get("key").toString() : null;
			String cacheStore = cacheParams.get("cacheStore") != null ? cacheParams.get("cacheStore").toString() : null;
			boolean isPut = cacheParams.get("isPut") != null ? Boolean.parseBoolean(cacheParams.get("isPut").toString()): false;
			long expiryTimeInSecond = cacheParams.get("ttlinseconds") != null ? Long.parseLong(cacheParams.get("ttlinseconds").toString()): 3600l;

			if (isPut) {

				deletCache(key, CacheStore.valueOf(cacheStore));
				returnObject = joinPoint.proceed(parameters);

			} else {

				returnObject = getCache(key, CacheStore.valueOf(cacheStore));
				if (returnObject == null) {

					returnObject = joinPoint.proceed(parameters);
					putCache(key, returnObject.toString(), expiryTimeInSecond, CacheStore.valueOf(cacheStore));
				}

			}
		} else {

			returnObject = joinPoint.proceed(parameters);
		}

		return returnObject;

	}

	/**
	 * Put value to Redis cache
	 * 
	 * @param key
	 *            Set key *
	 * @param value
	 *            Set value
	 * @param expiryTimeInSecond
	 * 
	 * @param cacheStore Set cachestore
	 */
	private void putCache(final String key, final String value, final long expiryTimeInSecond, final CacheStore cacheStore) {

		try {

			if (!StringUtils.isEmpty(key)) {

				cacheFactory.getCachStore(cacheStore).put(key, value, expiryTimeInSecond);
			} else {
				throw new CacheException("Invalid key " + key + "store cache.");
			}
		} catch (Exception e) {

			LOGGER.error("Error in store value in cache for key :" + key  + " Error: " + e.getMessage());

		}
	}

	/**
	 * Put value to Redis cache
	 * 
	 * @param key
	 *            Set key
	 * 
	 * 
	 * @param cacheStore Set cachestore
	 * 
	 */
	private void deletCache(final String key, final CacheStore cacheStore) {

		try {

			cacheFactory.getCachStore(cacheStore).deleteKey(key);
		} catch (Exception e) {

			LOGGER.error("Error in delete cache for key "+ key + " Error: " + e.getMessage());

		}
	}

	/**
	 * Put value to Redis cache
	 * 
	 * @param key
	 *            Set key
	 * @param value
	 *            Set value
	 *            
	 * @param cacheStore Set cachestore
	 * 
	 */
	private Object getCache(final String key, final CacheStore cacheStore) {

		Object returnObject = null;

		try {

			if (!StringUtils.isEmpty(key)) {

				returnObject = cacheFactory.getCachStore(cacheStore).get(key);
			} else {

				throw new CacheException("Invalid key " + key + " to store cache.");
			}
		} catch (Exception e) {

			LOGGER.error("Error get cache for key :" + key + " Error: " + e.getMessage());

		}

		return returnObject;
	}

}
