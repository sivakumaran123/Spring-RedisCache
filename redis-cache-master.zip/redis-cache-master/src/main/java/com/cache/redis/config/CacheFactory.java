package com.cache.redis.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cache.redis.repository.CacheRepository;
import com.cache.redis.utils.CacheException;
import com.cache.redis.utils.CacheStore;

@Component(value="cacheFactory")
public class CacheFactory {

	@Autowired
	@Qualifier("redisObjectCacheRepository")
	private CacheRepository redisObjectCacheRepository;
	
	
	public CacheRepository getCachStore(final CacheStore cacheStore) {
       
        if (cacheStore.equals(CacheStore.REDIS)) {
        	
            return redisObjectCacheRepository;
        } else {
            throw new CacheException("Unsupported cache store.");
        }
    }
	
}
